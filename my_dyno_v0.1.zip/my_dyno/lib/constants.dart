import 'package:intl/intl.dart';

const kVersion = 'v0.1';
const kDbPassword = 'dawix';
const kFbUrl = 'https://facebook.com/zapomnienie';
// TODO: wstaw swój link Buy Me a Coffee
const kCoffeeUrl = 'https://www.buymeacoffee.com/';
const kGeminiModel = 'gemini-flash-latest';

String fmtDate(DateTime d) => DateFormat('dd.MM.yyyy').format(d);
